package com.example.andoidstudiointro_singleterry;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText nameText;
    private TextView textGreeting;
    private Button SayHello;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameText = (EditText) findViewById(R.id.nameText);
        textGreeting = (TextView) findViewById(R.id.textGreeting);
        SayHello = (Button) findViewById(R.id.buttonSayHello);
        SayHello.setEnabled(false);


        nameText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) { }

            @Override
            public void afterTextChanged(Editable charSequence) {

                if (charSequence.toString().equals("")){
                    SayHello.setEnabled(false);
                } else {
                    SayHello.setEnabled(true);
                }
            }
        });
    }
}


