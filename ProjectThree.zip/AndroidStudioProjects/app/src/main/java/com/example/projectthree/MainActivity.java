package com.example.projectthree.;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ViewConfiguration;

public class MainActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
    }
}