package com.example.projectthree.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import java.util.List;

import  com.example.projectthree.database.CreateUser;
import  com.example.projectthree.database.DeleteUser;
public class LoginActivity extends AppCompatActivity {


}
