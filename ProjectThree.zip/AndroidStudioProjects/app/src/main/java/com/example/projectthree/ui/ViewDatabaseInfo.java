package com.example.projectthree.ui;

public class ViewDatabaseInfo {
}
