package com.example.projectthree.database;

public class SmsUserAgreement {
}
